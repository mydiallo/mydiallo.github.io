<?php

function comfirmQuery($create_member_query){

    global $connexion;

    if(!$create_member_query){
    die("QUERY FAILED ." . mysqli_error($conn));

    }
}

?>